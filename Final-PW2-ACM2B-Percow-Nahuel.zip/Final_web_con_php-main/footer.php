<?php 

$txt_foooter='
<footer class="background bg-dark">
<div class="container">
  <div class="row center">
    <div class="col-8 col-md-9 col-lg-10 footer">
    <p>Todos los derechos reservados <a href="index.php" class="cineOnline">CineOnline.com.ar</a></p>
    </div>
    <div class="col-4 col-md-3 col-lg-2 social-media">
      <a href="https://www.facebook.com/" target="_blank">
        <img src="img/banner_more/facebook.png" alt="facebook-icon" class="social-media" width="512" height="512">
      </a>
      <a href="https://www.instagram.com/" target="_blank">
        <img src="img/banner_more/instagram.png" alt="instagram-icon" class="social-media" width="512" height="512">
      </a>
      <a href="https://www.youtube.com/" target="_blank">
        <img src="img/banner_more/youtube.png" alt="youtube-icon" class="social-media" width="512" height="512">
      </a>
      <a href="https://twitter.com/" target="_blank">
        <img src="img/banner_more/twitter.png" alt="twitter-icon" class="social-media" width="512" height="512">
      </a>
    </div>
  </div>
</div>
</footer>';

echo $txt_foooter;

?>